
public class HotelStar {
	private int Star;
	private String Description;
	
	public int getStar() {
		return Star;
	}
	public void setStar(int star) {
		Star = star;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	
}
